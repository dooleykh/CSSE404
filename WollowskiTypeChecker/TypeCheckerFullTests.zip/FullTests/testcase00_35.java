// Valid

class A
{
   public static void main( String[] args )
   {
   }
}

class B
{
	C var;
}

class C
{

}