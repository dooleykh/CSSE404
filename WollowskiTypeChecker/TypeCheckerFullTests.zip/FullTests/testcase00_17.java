
class Main {
    public static void main(String[] args) {
        
    }
}

class Foo {    
    public int Foo(int Foo) {
        return Foo;
    }
}
