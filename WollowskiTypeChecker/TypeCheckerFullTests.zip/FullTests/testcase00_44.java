class foo {
	public static void main(String[] args) {
		System.out.println(bar.fib(4));
	}
}

class baz {
	public int fib(int a) {
		return true;
	}
}