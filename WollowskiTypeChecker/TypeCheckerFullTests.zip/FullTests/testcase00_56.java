//This one should work just fine

class Example
{
	public static void main(String[] args)
	{
		int args = 5;
	}
}
