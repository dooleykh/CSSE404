class botball{
	public static void main(String [] args){
		
	}
}

class battlebot extends botball{
	int a;
	int b;
	
	public int destroy(battlebot bot){
		a = 3;
		b = 5;
		b = a + b;
		int d = bot.destroy(this);
		
		return 0;
	}
	
}