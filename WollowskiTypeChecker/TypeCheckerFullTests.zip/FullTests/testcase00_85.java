class fred
{
	public static void main(String[] arg)
	{
		boolean x = false;
		int y = 0;
		y = 0;
		x = y;
	}
}
