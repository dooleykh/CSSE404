class Class1
{
	public static void main(String[] argv)
	{
		int x = true;
	}
}
