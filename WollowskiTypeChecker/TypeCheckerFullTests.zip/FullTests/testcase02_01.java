// checking case sensitivity
class Bar {
	public static void main(String[] args) {
		int x = 2;
		int y = 3;
		boolean X = false;
		Bar something = new Bar();
		y = X + x;
	}
}