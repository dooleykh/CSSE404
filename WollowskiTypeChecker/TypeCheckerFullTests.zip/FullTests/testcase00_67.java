class Test {
    public static void main(String[] args) {
	int x = 0;
	//args is just a placeholder... should not be able to be accessed
	System.out.println(args);
    }
}
