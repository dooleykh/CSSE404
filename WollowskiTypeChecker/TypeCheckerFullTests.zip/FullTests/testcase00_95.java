class NAME
{
	public static void main(String[] name) {
	}
}
class name
{
	int x;
	boolean y;
	public int getx() {
		return x;
	}
	public boolean gety() {
		return y;
	}
	public boolean compare()
	{
		if (true)
			boolean z = y && new name().gety();
		else
			x = 3;

		return true;
	}
}
class nam extends name
{
	public int getx()
	{
		System.out.println(2);
		return 2;
	}
}
