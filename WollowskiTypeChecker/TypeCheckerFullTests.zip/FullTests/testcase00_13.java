//Error case

class start{

	public static void main(String[] args){
		int b = 5;
	}
}

class start{

	public int main2(){
		return 5;
	}
}
