class good1 {
	public static void main(String[] args) {
		Class2 Class2 = new Class2();
		System.out.println(Class2.Class2(Class2));
	}
}
class Class2 {
	Class2 Class2;
	public Class2 Class2(Class2 Class2) {
		Class2 mycalls = new Class2();
		return Class2;
	}
}
class Class3 extends Class2 {
	public Class2 Class2(Class2 Class2) {
		Class3 mycalls = new Class3();
		return Class2;
	}
}
