class Main {
	public static void main(String[] args) {
		int a = 0;
		int b = 1;
		boolean c = a || b;
	}
}