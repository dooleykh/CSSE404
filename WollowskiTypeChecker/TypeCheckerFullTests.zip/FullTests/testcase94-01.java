

class kfupm{
	public static void main (String [] args){
		
		int a1 = 1;
		int a2 = 2;
		
		int a3 = a1 + a2;
		boolean a4 = true;
		ksu ins = null;
		
		
		if(a4)
		{
			System.out.println(a1+a2);
			
		}
		else
		{
			
			System.out.println(a1 * a2);
		}
		
	}
}

class kaust extends kfupm{
	int i;
	int j;
	int k;
	
	public boolean happy(){
		int csse = 15;
		ksu student = null;
		return true;
	}
}

class ksu{
	int riyadh;
	int jeddah;
	
	public boolean happy(){
		return false;
	}
}