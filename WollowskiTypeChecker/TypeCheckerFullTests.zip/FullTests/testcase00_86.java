class Class1
{
	public static void main (String[] arg)
	{
		boolean z = arg;
	}
}
