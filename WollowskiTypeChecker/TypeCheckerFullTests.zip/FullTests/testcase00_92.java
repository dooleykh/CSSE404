class NAME
{
	public static void main(String[] name) {
	}
}
class name
{
	int x;
	boolean y;
	public int getx() {
		return x;
	}
	public boolean gety() {
		return y;
	}
	public boolean compare()
	{
		if (3)
			x=3;
		else
			x=2;

		return true;
	}
}
