class fullTest02 {
	public static void main (String[] args){
		fullTest02 ft = this;
	}
}