/* Invalid: Undeclared type */
class Foo 
{ 
	public static void main(String[] args) 
	{ 
	}
}

class Bar
{ 
	Baz x;
}