class LightBulb {
	public static void main(String [] surrealists) {
		int giraffeHolder = 1;
		LightBulb BathtubFiller = new LightBulb();
		int howMany = giraffeHolder + BathtubFiller;
	}
}

