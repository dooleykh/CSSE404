

class kfupm{
	public static void main (String [] args){
		
		int a1 = 1;
		int a2 = 2;
		
		boolean a3 = a1 + a2;
		
		
	}
}

class kaust extends kfupm{
	int i;
	int j;
	int k;
	
	public boolean happy(){
		int csse = 0;
		return true;
	}
}