// Invalid assignment of variable a

class bar
{
	public static void main(String[] args)
	{
		bool a = 4;
	}
}
