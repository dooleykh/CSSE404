class Id { public static void main ( String [] args ) {
	int x = 5;
	boolean increase = true;
	
	if ( increase )
		x = x + increase;
	else
		{}

	System.out.println(x);
} }