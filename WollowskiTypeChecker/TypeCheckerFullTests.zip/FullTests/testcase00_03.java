// class not defined

class A
{
   public static void main( String[] args )
   {
      System.out.println( 0 );
   }
}

class B
{
   public boolean start( C c )
   {
      return false;
   }
}

