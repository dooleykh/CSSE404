class EntryPoint { public static void main(String[] args) {} }

class Point {
	public int hello() {
		a = c;
		int i = 3;
		int i = 4;
		boolean b = 0;
		boolean c = false;
		i = i;
		i = c;
		c = b;
		i = b;
		System.out.println(i);
		System.out.println(c);
		System.out.println(b);
		return 1;
	}
}