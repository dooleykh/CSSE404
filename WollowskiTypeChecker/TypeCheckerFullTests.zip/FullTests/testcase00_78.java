class EntryPoint {
	public static void main(String[] args) {
		int x = 1;
		if(1) {
			x = 2;
		} else {
			x = 3;
		}
		while(1) {
			x = 4;
		}
	}
}