
class Test 
{ //this is a class declaration.
	public static void main(String[] args)
	{			}

}

class Extra extends NextOne
{

}

class NextOne
{
	//oops, can't declare em in this order.
}