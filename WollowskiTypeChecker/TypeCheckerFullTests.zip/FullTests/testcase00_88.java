class brains
{
	public static void main(String[] argv)
	{
		System.out.println(3 + 4);
	}
}
