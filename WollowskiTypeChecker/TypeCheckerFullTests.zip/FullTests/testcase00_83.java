class A
{
	public static void main(String[] aardvark)
	{
		int a = 3;
		int b = 4;
		
		boolean y = true;
		boolean z = false;
		
		int result = 0;
		boolean boolResult = false;
		
		result = a + b;
		result = a - b;
		result = a * b;
		result = a / b;
/*		
		result = a < b;
		result = a > b;
		result = a <= b;
		result = a >= b;
		result = a == b;
		result = a != b;

*/
		
		boolResult = a < b;
		boolResult = a > b;
		boolResult = a <= b;
		boolResult = a >= b;
		boolResult = a == b;
		boolResult = a != b;

		
		result = a && b;
/*
		result = a || b;
		
		
		result = a + y;
		result = a - y;
		result = a * y;
		result = a / y;
		
		result = a < y;
		result = a > y;
		result = a <= y;
		result = a >= y;
		result = a == y;
		result = a != y;
		
		boolResult = a < y;
		boolResult = a > y;
		boolResult = a <= y;
		boolResult = a >= y;
		boolResult = a == y;
		boolResult = a != y;
		
		result = a && y;
		result = a || y;
		
		
		result = z + y;
		result = z - y;
		result = z * y;
		result = z / y;
		
		result = z < y;
		result = z > y;
		result = z <= y;
		result = z >= y;
		result = z == y;
		result = z != y;
		
		boolResult = z < y;
		boolResult = z > y;
		boolResult = z <= y;
		boolResult = z >= y;
*/
		boolResult = z == y;
		boolResult = z != y;
		
		boolResult = z && y;
		boolResult = z || y;
		
	}
	
}
