class NAME
{
	public static void main(String[] name) {
		int a = 0;
		boolean g = false;
	}
}
