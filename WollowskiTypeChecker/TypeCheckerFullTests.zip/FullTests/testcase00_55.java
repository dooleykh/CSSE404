class Test 
{ //this is a class declaration.
	public static void main(String[] args)


{
	int x = 5+3;
	boolean x= 5-3;
					}
//this file is a mess.
}