class TopClass {
	public static void main(String[] args){
	
	}
}

class SecondClass {
	public boolean incorrect() {
		if(3+2){
			System.out.println(4);
		}
		else {
			System.out.println(5);
		}
		return false;
	}
}