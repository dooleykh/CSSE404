class Blub{
    public static void main(String[] args){}
}

class Blob{
    public Blob foo(int Blob){
	Blob blob = new Blob();
	return Blob;
    }
}