class EntryPoint {
	public static void main(String[] args) {
		Point p = new Point();
		Point q = new Point();
	}
}

class Point extends DoesNotExist {}

class Point {}

class Point {}