
class Main {
    public static void main(String[] args) {
        
    }
}

class Foo {
    int Foo;
    int foo;
}

class Bar extends Foo {
    int l1;
    int O0;
    
    public int baz(boolean abc) {
        return 0;
    }
    
}

class Baz extends Foo {
    
    public int baz(boolean Foo) {
        return 1;
    }
    
}

