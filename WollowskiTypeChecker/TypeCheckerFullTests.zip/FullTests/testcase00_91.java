class NAME
{
	public static void main(String[] name) {
	}
}
class name
{
	int x;
	boolean y;
	public int getx() {
		return x;
	}
	public boolean gety() {
		return x;
	}
	public boolean compare()
	{
		return null||true;
	}
}
