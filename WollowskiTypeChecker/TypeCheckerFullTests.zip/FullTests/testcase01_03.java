class A1 {
    public static void main(String[] a2) {
	System.out.println(1);
    }
}

class double {}

class A3 {
    public boolean a6(boolean a7) {
	return !a7;
    }
}

class A8 extends A3 {
    public boolean a9(boolean a7) {
	if(a7 && 3) { //Int instead of boolean
	} else {}
	return true;
    }
}
