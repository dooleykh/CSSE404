class Test1 {
    public static void main(String[] args) {
        if (true) {
            int b = 5;
        } else {
            int b = 5;
        }
        
        b = 5; // b not in scope
    }
}
